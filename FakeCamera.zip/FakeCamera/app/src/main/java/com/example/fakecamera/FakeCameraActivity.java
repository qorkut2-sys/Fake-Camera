package com.example.fakecamera;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.ParcelFileDescriptor;
import android.provider.MediaStore;
import android.util.Log;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import java.io.File;
import java.io.FileDescriptor;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * FakeCameraActivity - Menangkap intent IMAGE_CAPTURE dari aplikasi lain
 *
 * Cara kerja:
 * - Saat aplikasi lain (misal: WhatsApp, form KYC, dll) memanggil kamera
 *   dengan Intent ACTION_IMAGE_CAPTURE, activity ini yang akan menangkap intent tersebut
 * - Kemudian mengembalikan gambar yang sudah dipilih user seolah-olah itu hasil foto kamera
 */
public class FakeCameraActivity extends Activity {

    private static final String TAG = "FakeCameraActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Ambil URI gambar yang sudah disimpan
        SharedPreferences prefs = getSharedPreferences(
                MainActivity.PREFS_NAME, MODE_PRIVATE);
        String savedUri = prefs.getString(MainActivity.KEY_IMAGE_URI, null);

        if (savedUri == null) {
            // Tidak ada gambar dipilih, beri tahu user
            Toast.makeText(this,
                    "Buka Fake Camera dan pilih gambar terlebih dahulu!",
                    Toast.LENGTH_LONG).show();
            setResult(RESULT_CANCELED);
            finish();
            return;
        }

        Uri imageUri = Uri.parse(savedUri);
        handleCameraIntent(imageUri);
    }

    /**
     * Proses intent kamera dan kembalikan gambar palsu
     */
    private void handleCameraIntent(Uri sourceUri) {
        Intent callerIntent = getIntent();

        try {
            // Baca gambar dari URI yang disimpan
            Bitmap bitmap = loadBitmapFromUri(sourceUri);

            if (bitmap == null) {
                Toast.makeText(this, "Gagal memuat gambar", Toast.LENGTH_SHORT).show();
                setResult(RESULT_CANCELED);
                finish();
                return;
            }

            // Cek apakah caller menyediakan output URI (EXTRA_OUTPUT)
            Uri outputUri = callerIntent.getParcelableExtra(MediaStore.EXTRA_OUTPUT);

            if (outputUri != null) {
                // Caller ingin gambar disimpan ke URI tertentu
                writeToOutputUri(bitmap, outputUri);
                setResult(RESULT_OK);
            } else {
                // Caller ingin gambar dikembalikan sebagai thumbnail Bitmap
                returnBitmapThumbnail(bitmap);
            }

        } catch (Exception e) {
            Log.e(TAG, "Error handling camera intent", e);
            Toast.makeText(this, "Terjadi kesalahan: " + e.getMessage(),
                    Toast.LENGTH_SHORT).show();
            setResult(RESULT_CANCELED);
        }

        finish();
    }

    /**
     * Load Bitmap dari URI
     */
    private Bitmap loadBitmapFromUri(Uri uri) {
        try {
            ParcelFileDescriptor pfd = getContentResolver().openFileDescriptor(uri, "r");
            if (pfd != null) {
                FileDescriptor fd = pfd.getFileDescriptor();
                Bitmap bitmap = BitmapFactory.decodeFileDescriptor(fd);
                pfd.close();
                return bitmap;
            }
        } catch (IOException e) {
            Log.e(TAG, "Error loading bitmap", e);
        }
        return null;
    }

    /**
     * Tulis bitmap ke URI output yang diminta caller
     * (digunakan saat caller memberikan EXTRA_OUTPUT)
     */
    private void writeToOutputUri(Bitmap bitmap, Uri outputUri) throws IOException {
        FileOutputStream fos = (FileOutputStream) getContentResolver()
                .openOutputStream(outputUri);
        if (fos != null) {
            // Compress dengan kualitas 95% dalam format JPEG
            bitmap.compress(Bitmap.CompressFormat.JPEG, 95, fos);
            fos.flush();
            fos.close();
        }
    }

    /**
     * Kembalikan bitmap sebagai thumbnail (tanpa EXTRA_OUTPUT)
     * Ukuran max 512x512 agar tidak melebihi batas Binder transaction
     */
    private void returnBitmapThumbnail(Bitmap bitmap) {
        // Scale down jika terlalu besar
        Bitmap thumbnail = scaleBitmap(bitmap, 512, 512);

        Intent resultIntent = new Intent();
        resultIntent.putExtra("data", thumbnail);
        setResult(RESULT_OK, resultIntent);
    }

    /**
     * Scale bitmap ke ukuran maksimum dengan mempertahankan aspect ratio
     */
    private Bitmap scaleBitmap(Bitmap original, int maxWidth, int maxHeight) {
        int width  = original.getWidth();
        int height = original.getHeight();

        float scaleWidth  = (float) maxWidth  / width;
        float scaleHeight = (float) maxHeight / height;
        float scale = Math.min(scaleWidth, scaleHeight);

        if (scale >= 1.0f) return original; // Tidak perlu di-scale

        int newWidth  = Math.round(width  * scale);
        int newHeight = Math.round(height * scale);

        return Bitmap.createScaledBitmap(original, newWidth, newHeight, true);
    }
}
