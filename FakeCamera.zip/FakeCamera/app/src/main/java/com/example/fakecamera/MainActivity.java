package com.example.fakecamera;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.io.FileNotFoundException;
import java.io.InputStream;

/**
 * MainActivity - Halaman utama aplikasi Fake Camera
 *
 * Fungsi:
 * 1. Pilih gambar dari galeri
 * 2. Preview gambar yang dipilih
 * 3. Set gambar sebagai "foto kamera palsu"
 */
public class MainActivity extends AppCompatActivity {

    // Request codes
    private static final int REQUEST_PICK_IMAGE = 100;
    private static final int REQUEST_PERMISSION_STORAGE = 200;

    // Shared Preferences key
    public static final String PREFS_NAME = "FakeCameraPrefs";
    public static final String KEY_IMAGE_URI = "selected_image_uri";

    // UI Components
    private ImageView imgPreview;
    private Button btnPickImage;
    private Button btnClearImage;
    private TextView tvStatus;
    private TextView tvGuide;

    // URI gambar yang dipilih
    private Uri selectedImageUri = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initViews();
        loadSavedImage();
        setupClickListeners();
    }

    /**
     * Inisialisasi semua komponen UI
     */
    private void initViews() {
        imgPreview   = findViewById(R.id.img_preview);
        btnPickImage = findViewById(R.id.btn_pick_image);
        btnClearImage = findViewById(R.id.btn_clear_image);
        tvStatus     = findViewById(R.id.tv_status);
        tvGuide      = findViewById(R.id.tv_guide);
    }

    /**
     * Load gambar yang sudah disimpan sebelumnya
     */
    private void loadSavedImage() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        String savedUri = prefs.getString(KEY_IMAGE_URI, null);

        if (savedUri != null) {
            selectedImageUri = Uri.parse(savedUri);
            showImagePreview(selectedImageUri);
            tvStatus.setText("✅ Gambar aktif sebagai kamera palsu");
            tvStatus.setTextColor(getResources().getColor(android.R.color.holo_green_dark));
        } else {
            tvStatus.setText("❌ Belum ada gambar dipilih");
            tvStatus.setTextColor(getResources().getColor(android.R.color.holo_red_dark));
        }
    }

    /**
     * Setup semua tombol klik
     */
    private void setupClickListeners() {

        // Tombol pilih gambar dari galeri
        btnPickImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkPermissionAndPickImage();
            }
        });

        // Tombol hapus gambar
        btnClearImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clearSelectedImage();
            }
        });
    }

    /**
     * Cek permission storage sebelum buka galeri
     */
    private void checkPermissionAndPickImage() {
        String permission;

        // Android 13+ pakai READ_MEDIA_IMAGES, di bawahnya READ_EXTERNAL_STORAGE
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permission = Manifest.permission.READ_MEDIA_IMAGES;
        } else {
            permission = Manifest.permission.READ_EXTERNAL_STORAGE;
        }

        if (ContextCompat.checkSelfPermission(this, permission)
                != PackageManager.PERMISSION_GRANTED) {
            // Minta permission
            ActivityCompat.requestPermissions(this,
                    new String[]{permission},
                    REQUEST_PERMISSION_STORAGE);
        } else {
            openGallery();
        }
    }

    /**
     * Buka galeri untuk pilih gambar
     */
    private void openGallery() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        intent.setType("image/*");
        startActivityForResult(Intent.createChooser(intent, "Pilih Gambar"), REQUEST_PICK_IMAGE);
    }

    /**
     * Tampilkan preview gambar di ImageView
     */
    private void showImagePreview(Uri uri) {
        try {
            InputStream inputStream = getContentResolver().openInputStream(uri);
            Bitmap bitmap = BitmapFactory.decodeStream(inputStream);
            imgPreview.setImageBitmap(bitmap);
            imgPreview.setVisibility(View.VISIBLE);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            Toast.makeText(this, "Gagal memuat gambar", Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Simpan URI gambar ke SharedPreferences
     */
    private void saveImageUri(Uri uri) {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        prefs.edit().putString(KEY_IMAGE_URI, uri.toString()).apply();
    }

    /**
     * Hapus gambar yang sudah dipilih
     */
    private void clearSelectedImage() {
        selectedImageUri = null;

        // Hapus dari SharedPreferences
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        prefs.edit().remove(KEY_IMAGE_URI).apply();

        // Reset UI
        imgPreview.setImageResource(R.drawable.ic_placeholder);
        tvStatus.setText("❌ Belum ada gambar dipilih");
        tvStatus.setTextColor(getResources().getColor(android.R.color.holo_red_dark));

        Toast.makeText(this, "Gambar dihapus", Toast.LENGTH_SHORT).show();
    }

    /**
     * Handle hasil dari pemilihan gambar di galeri
     */
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_PICK_IMAGE && resultCode == RESULT_OK && data != null) {
            Uri imageUri = data.getData();

            if (imageUri != null) {
                // Simpan permission akses URI agar bisa dipakai nanti
                getContentResolver().takePersistableUriPermission(
                        imageUri,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION
                );

                selectedImageUri = imageUri;
                saveImageUri(imageUri);
                showImagePreview(imageUri);

                tvStatus.setText("✅ Gambar aktif sebagai kamera palsu");
                tvStatus.setTextColor(getResources().getColor(android.R.color.holo_green_dark));

                Toast.makeText(this,
                        "Gambar berhasil dipilih!\nSekarang gunakan kamera di aplikasi lain.",
                        Toast.LENGTH_LONG).show();
            }
        }
    }

    /**
     * Handle hasil request permission
     */
    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == REQUEST_PERMISSION_STORAGE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                openGallery();
            } else {
                Toast.makeText(this,
                        "Permission diperlukan untuk mengakses galeri",
                        Toast.LENGTH_SHORT).show();
            }
        }
    }
}
